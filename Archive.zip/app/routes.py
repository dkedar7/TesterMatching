from app import app
from flask import render_template,request
import pandas as pd

bugs = pd.read_csv("Data/bugs.csv")
devices = pd.read_csv('Data/devices.csv')
tester_device = pd.read_csv('Data/tester_device.csv')
testers = pd.read_csv('Data/testers.csv')

def query(country_list,device_list):

    testers['BugsTested'] = bugs.groupby('testerId').agg({'bugId':'count'}).astype(int).values

    if 'all_devices' in device_list:
        query_by_device = testers
    else:
        device_id = devices[devices.description.isin(device_list)].deviceId.tolist()
        query_by_device = testers.iloc[tester_device[tester_device.deviceId.isin(device_id)].
             testerId.unique()-1,:]

    if 'all_countries' in country_list:
        country_list = testers.country.unique()
        final_query = query_by_device[['firstName',
                                       'lastName',
                                       'country',
                                       'BugsTested']].sort_values('BugsTested',ascending=False)

    else:
        final_query = query_by_device[query_by_device.country.isin(country_list)][['firstName',
                                                               'lastName',
                                                                'country',
                                                              'BugsTested']].sort_values('BugsTested',
                                                                                        ascending=False)

    final_query.index = range(1,len(final_query)+1)
    final_query.columns = ['First Name','Last Name','Country','Number of Bugs Tested']
    return final_query

@app.route('/', methods=['GET', 'POST'])
@app.route('/index')
def index():

    if request.method == 'POST':
        device_list = request.form.getlist('device')
        country_list = request.form.getlist('country')

    display_table = query(country_list,device_list)

    return render_template('index.html',tables=[display_table.to_html()], titles=display_table.columns.values,classes="table")
